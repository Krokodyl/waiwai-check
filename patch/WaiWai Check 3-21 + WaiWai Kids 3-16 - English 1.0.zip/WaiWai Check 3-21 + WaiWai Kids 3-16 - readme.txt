This is the English patch 1.0 for the Satellaview games:
- WaiWai Check 3/21
- WaiWai Kids 3/16

The games are translated together as they are part of the same dump.

File: WaiWai Check 3-21 Saihousou + WaiWai Kids 3-16.bs
File/ROM SHA-1: FE67F40912E7C4D290EEB175A2BD2122BFA3AE8C
File/ROM CRC32: 17239E91

More info on https://github.com/Krokodyl/waiwai-check