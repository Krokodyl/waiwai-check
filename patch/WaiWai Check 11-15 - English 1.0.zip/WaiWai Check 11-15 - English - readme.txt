This is the English patch 1.0 for the Satellaview game Waiwai Check 11/15.

File: [Ballz]WaiWai Check 11-15 Saihousou.bs
File/ROM SHA-1: 1725FF76E457F7A8D5E741BE9EDC549FAE145979
File/ROM CRC32: C557DB3A

More info on https://github.com/Krokodyl/waiwai-check